from flask import Flask, render_template, request, jsonify
import os

app = Flask(__name__)

contacts = [
    {"id": 1, "name": "Dr. John Doe", "city": "Beirut", "specialization": "Cardiologist", "fees": 1500, "rating": 4.8},
    {"id": 2, "name": "Dr. Jane Smith", "city": "Tripoli", "specialization": "Neurosurgeon", "fees": 2000, "rating": 4.5},
]

@app.route('/api/contacts', methods=['GET'])
def get_contacts():
    return jsonify(contacts)

@app.route('/api/contacts', methods=['POST'])
def add_contact():
    new_contact = request.get_json()
    new_contact['id'] = len(contacts) + 1
    contacts.append(new_contact)
    return jsonify({"message": "Contact added successfully!", "contact": new_contact}), 201

@app.route('/api/contacts/<int:contact_id>', methods=['PUT'])
def update_contact(contact_id):
    for contact in contacts:
        if contact['id'] == contact_id:
            data = request.get_json()
            contact.update(data)
            return jsonify({"message": "Contact updated successfully!", "contact": contact})
    return jsonify({"message": "Contact not found!"}), 404

@app.route('/api/contacts/<int:contact_id>', methods=['DELETE'])
def delete_contact(contact_id):
    global contacts
    contacts = [contact for contact in contacts if contact['id'] != contact_id]
    return jsonify({"message": "Contact deleted successfully!"})


@app.route('/api/recommend', methods=['GET'])
def recommend():
    city = request.args.get('city', '').lower()
    max_fees = float(request.args.get('max_fees', 2000))
    min_rating = float(request.args.get('min_rating', 4.0))

    recommendations = [
        contact for contact in contacts
        if contact['city'].lower() == city and
           contact['fees'] <= max_fees and
           contact['rating'] >= min_rating
    ]

    return jsonify(recommendations)

@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    from flask.helpers import get_available_port
    app.run(host='0.0.0.0', port=get_available_port())