document.getElementById('search-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const query = document.getElementById('query').value;
    const resultsDiv = document.getElementById('results');

    const params = new URLSearchParams();
    const [specialization, city, rating, cost] = query.split(" ");
    params.append("city", city);
    params.append("max_fees", cost.split("=")[1]);
    params.append("min_rating", rating.split("=")[1]);

    const response = await fetch(`/api/recommend?${params.toString()}`);
    const data = await response.json();

    resultsDiv.innerHTML = `
        <h2>Recommended Contacts</h2>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>City</th>
                    <th>Specialization</th>
                    <th>Fees</th>
                    <th>Rating</th>
                </tr>
            </thead>
            <tbody>
                ${data.map(contact => `
                    <tr>
                        <td>${contact.id}</td>
                        <td>${contact.name}</td>
                        <td>${contact.city}</td>
                        <td>${contact.specialization}</td>
                        <td>${contact.fees}</td>
                        <td>${contact.rating}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
});
