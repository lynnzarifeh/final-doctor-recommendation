from flask import Flask, render_template, request, jsonify
import sqlite3

app = Flask(__name__)

def init_db():
    """Initialize the SQLite database."""
    conn = sqlite3.connect('contacts.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS contacts (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT,
                        specialty TEXT,
                        city TEXT,
                        address TEXT,
                        fees REAL,
                        recommendations INTEGER
                    )''')
    conn.commit()
    conn.close()

@app.route('/')
def index():
    """Render the main HTML page."""
    return render_template('index.html')

@app.route('/contacts', methods=['GET'])
def get_contacts():
    """Retrieve all contacts."""
    conn = sqlite3.connect('contacts.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM contacts")
    contacts = cursor.fetchall()
    conn.close()
    return jsonify(contacts)

@app.route('/contacts', methods=['POST'])
def add_contact():
    """Add a new contact."""
    data = request.json
    conn = sqlite3.connect('contacts.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO contacts (name, specialty, city, address, fees, recommendations) VALUES (?, ?, ?, ?, ?, ?)",
                   (data['name'], data['specialty'], data['city'], data['address'], data['fees'], data['recommendations']))
    conn.commit()
    conn.close()
    return jsonify({"message": "Contact added successfully!"}), 201

@app.route('/contacts/<int:contact_id>', methods=['PUT'])
def update_contact(contact_id):
    """Update an existing contact."""
    data = request.json
    conn = sqlite3.connect('contacts.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE contacts SET name = ?, specialty = ?, city = ?, address = ?, fees = ?, recommendations = ? WHERE id = ?",
                   (data['name'], data['specialty'], data['city'], data['address'], data['fees'], data['recommendations'], contact_id))
    conn.commit()
    conn.close()
    return jsonify({"message": "Contact updated successfully!"})

@app.route('/contacts/<int:contact_id>', methods=['DELETE'])
def delete_contact(contact_id):
    """Delete a contact."""
    conn = sqlite3.connect('contacts.db')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM contacts WHERE id = ?", (contact_id,))
    conn.commit()
    conn.close()
    return jsonify({"message": "Contact deleted successfully!"})

@app.route('/recommendations', methods=['POST'])
def get_recommendations():
    """Get recommended contacts based on query parameters."""
    data = request.json
    city = data.get('city')
    max_fees = data.get('max_fees')
    specialty = data.get('specialty')

    query = "SELECT * FROM contacts WHERE city = ? AND fees <= ? AND specialty = ? ORDER BY recommendations DESC"
    conn = sqlite3.connect('contacts.db')
    cursor = conn.cursor()
    cursor.execute(query, (city, max_fees, specialty))
    recommendations = cursor.fetchall()
    conn.close()
    return jsonify(recommendations)

import sqlite3

# Initialize database connection
def insert_sample_data():
    conn = sqlite3.connect('contacts.db')
    cursor = conn.cursor()

    # Sample data to insert
    sample_contacts = [
        ("John Doe", "Cardiologist", "New York", "123 Heart St.", 1500.0, 10),
        ("Jane Smith", "Neurologist", "San Francisco", "456 Brain Ln.", 2000.0, 15),
        ("Emily White", "Orthopedic", "Chicago", "789 Bone Rd.", 1800.0, 12),
        ("Michael Brown", "Pediatrician", "Los Angeles", "101 Kid Dr.", 1200.0, 20)
    ]

    # Insert sample data
    cursor.executemany("""
        INSERT INTO contacts (name, specialty, city, address, fees, recommendations)
        VALUES (?, ?, ?, ?, ?, ?)
    """, sample_contacts)

    # Commit and close connection
    conn.commit()
    conn.close()
    print("Sample data inserted successfully!")

# Call the function



if __name__ == '__main__':
    init_db()
    app.run(debug=True)